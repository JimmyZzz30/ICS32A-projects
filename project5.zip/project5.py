import columns_game as game
import pygame
import random

ROWS = 13
COLS = 6
FRAME_RATE=5

JEWELS = ['S', 'T', 'V', 'W', 'X', 'Y', 'Z']


def _get_jewel_color(jewel: str) -> (int, int, int):
    """
    Gets the color of a given jewel as a tuple
    :param jewel: The jewel to get the color of
    :return: A tuple where the first value is the Red, the second value is the Green, and the third value is the Blue.
    """
    if jewel == 'S':  # Red
        return (255, 0, 0)
    elif jewel == 'T':  # Green
        return (0, 255, 0)
    elif jewel == 'V':  # Blue
        return (0, 0, 255)
    elif jewel == 'W':  # Yellow
        return (255, 255, 0)
    elif jewel == 'X':  # Orange
        return (255, 128, 0)
    elif jewel == 'Y':  # Pink
        return (255, 0, 255)
    elif jewel == 'Z':  # Light blue
        return (0, 255, 255)


class Game:

    def __init__(self):
        self._state = game.GameState(ROWS, COLS)

        self._count = FRAME_RATE
        self._running = True


        self._background = pygame.Color(0, 0, 0)
        self._gamebox_color = pygame.Color(255, 255, 255)
        self._top = 0
        self._jewel_size = 1/self._state._rows
        self._side = 1-(self._jewel_size * self._state._columns)

    def run(self) -> None:
        pygame.init()

        try:
            clock = pygame.time.Clock()

            self._create_surface((600, 600))

            while self._running:
                clock.tick(FRAME_RATE)

                self._handle_events()

                self._count-= 1

                if self._count== 0:
                    self._refresh_game()
                    self._count = FRAME_RATE

                self._draw_frame()

        finally:
            pygame.quit()

    def _refresh_game(self) -> None:
        self._running = not self._state.tick()
        if not self._state._faller.active:
            contents = (random.choice(JEWELS),random.choice(JEWELS),random.choice(JEWELS))
            column = random.randint(1, COLS)
            self._state.create_faller(column, contents)

    def _create_surface(self,size:tuple[int,int])->None:
        self._surface=pygame.display.set_mode(size,pygame.RESIZABLE)

    def _handle_events(self)->None:
        for event in pygame.event.get():
            self._handle_event(event)
            
        self._handle_keys()
        
    def _handle_event(self,event)->None:
        if event.type == pygame.QUIT:
            self._stop_running()
        elif event.type == pygame.VIDEORESIZE:
            self._create_surface(event.size)
            
    def _handle_keys(self)->None:
        keys=pygame.key.get_pressed()
        if keys[pygame.K_RIGHT]:
            self._state.move_faller_side(game.RIGHT)
        if keys[pygame.K_LEFT]:
            self._state.move_faller_side(game.LEFT)
        if keys[pygame.K_SPACE]:
            self._state.rotate_faller()
            
    def _stop_running(self):
        self._running=False
        
    def _draw_frame(self):
        self._surface.fill(self._background)
        self._draw_gamebox()
        pygame.display.flip()
        
    def _draw_gamebox(self):
        top_left_pixel_x=self._frac_x_to_pixel_x((self._side/2))
        top_left_pixel_y=self._frac_y_to_pixel_y((self._top/2))
        width_pixel = self._frac_x_to_pixel_x(self._jewel_size*self._state._columns)
        height_pixel = self._frac_y_to_pixel_y(self._jewel_size*self._state._rows)
        gamebox = pygame.Rect(top_left_pixel_x,top_left_pixel_y,width_pixel,height_pixel)
        pygame.draw.rect(self._surface,self._gamebox_color,gamebox)
        for row in range(self._state._rows):
            for col in range(self._state._columns):
                self._draw_jewel(row,col)
                
    def _draw_jewel(self,row:int,col:int)->None:
        jewel=self._state.get_cell_contents(row,col)
        if jewel == game.EMPTY:
            return
        init_color=None
        state = self._state.get_cell_state(row,col)
        if state == game.MATCHED_CELL:
            init_color = (255,215,0)
        else:
            init_color = _get_jewel_color(jewel)
        color = pygame.Color(init_color[0],init_color[1],init_color[2])
        jewel_x = (col*self._jewel_size)+(self._side/2)
        jewel_y = (row*self._jewel_size)+(self._top/2)
        top_left_x = self._frac_x_to_pixel_x(jewel_x)
        top_left_y = self._frac_y_to_pixel_y(jewel_y)

        width = self._frac_x_to_pixel_x(self._jewel_size)
        height = self._frac_y_to_pixel_y(self._jewel_size)
        rect = pygame.Rect(top_left_x,top_left_y,width,height)
        pygame.draw.rect(self._surface,color,rect,0)
        if state == game.FALLER_STOPPED_CELL:
            pygame.draw.ellipse(self._surface, pygame.Color(255, 255, 255), rect)
            
                
    def _frac_x_to_pixel_x(self, frac_x: float) -> int:
        return self._frac_to_pixel(frac_x, self._surface.get_width())


    def _frac_y_to_pixel_y(self, frac_y: float) -> int:
        return self._frac_to_pixel(frac_y, self._surface.get_height())


    def _frac_to_pixel(self, frac: float, max_pixel: int) -> int:
        return int(frac * max_pixel)
            
if __name__=='__main__':
    Game().run()
