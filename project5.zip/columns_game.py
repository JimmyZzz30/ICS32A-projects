EMPTY_CELL = 'EMPTY'
FALLER_MOVING_CELL = 'MOVING'
FALLER_STOPPED_CELL = 'STOP'
OCCUPIED_CELL = 'OCCUPIED'
MATCHED_CELL = 'MATCHED'

LEFT = -1
RIGHT = 1
DOWN = 0


EMPTY = ' '
CONTENTS={EMPTY,'S','T','V','W','X','Y','Z'}

class InvalidMoveError(Exception):
    pass
class GameOverError(Exception):
    pass


class GameState:
    def __init__(self, rows: int, columns: int):
        '''create a new game with all empty cell and empty state'''
        self._rows = rows
        self._columns = columns
        self._board= []
        self._boardStates = []
        self._faller = _Faller()
        for i in range(rows):
            row = []
            state= []
            for j in range(columns):
                row.append(EMPTY)
                state.append(EMPTY_CELL)
            self._board.append(row)
            self._boardStates.append(state)

    def set_board_contents(self, contents: [[str]]) -> None:
        '''set contents in board'''
        for row in range(self._rows):
            for col in range(self._columns):
                value = contents[row][col]
                if value is EMPTY:
                    self._set_cell(row, col, EMPTY, EMPTY_CELL)
                else:
                    self._set_cell(row, col, value, OCCUPIED_CELL)

        self._gravity()
        self._matching()

    def tick(self) -> bool:
        '''one tick is one time for faller to take action'''
        if self._faller.active:
            if self._faller.state == _FALLER_STOPPED:
                self._update()
                if self._faller.state == _FALLER_STOPPED:# If the faller is still stop after the update then freeze it
                    value = False
                    if self._faller._row- 2 < 0:
                        value = True

                    for i in range(3):
                        self._set_cell(self._faller._row- i, self._faller._col, self._faller.contents[i],
                                       OCCUPIED_CELL)
                    self._faller.active = False

                    self._matching()
                    return value

            self._move_faller_down()
            self._update()

        self._matching()
        return False

    def create_faller(self, column: int, faller: [str, str, str]) -> None:
        '''create a faller in given column and contents'''
        if self._faller.active:
            return

        self._faller.active = True
        self._faller.contents = faller
        self._faller._row = 0
        self._faller._col = column - 1
        self._set_cell(0, self._faller._col, self._faller.contents[0], FALLER_MOVING_CELL)

        
        self._update()


    def rotate_faller(self) -> None:
        if self._faller.active== False:
            return

        up = self._faller.contents[0]
        middle = self._faller.contents[1]
        bottom = self._faller.contents[2]

        self._faller.contents = [middle, bottom,up]
        for i in range(3):
            self._set_cell_contents(self._faller._row- i, self._faller._col, self._faller.contents[i])
        self._update()

    def move_faller_side(self, direction: int) -> None:
        '''move faller to left or right only'''
        if  self._faller.active==False:
            return

        if direction!=RIGHT and direction!=LEFT:
            return

        if (direction == LEFT and self._faller._col== 0) or (direction == RIGHT and self._faller._col== self._columns-1):
            return

        new_col = self._faller._col+ direction
        for i in range(len(self._faller.contents)):
            if self._faller._row- i < 0:
                break

            if self.get_cell_state(self._faller._row- i, new_col) == OCCUPIED_CELL:
                return
        for i in range(len(self._faller.contents)):
            if self._faller._row- i < 0:
                break
            self._move_cell(self._faller._row- i, self._faller._col, direction)

        self._faller.set_col(new_col)

        self._update()

    

    def get_cell_state(self, row: int, col: int) -> str:
        '''get the state of given cell'''
        return self._boardStates[row][col]

    def get_cell_contents(self, row: int, col: int) -> str:
        '''get the contents of given cell'''
        return self._board[row][col]

    def _set_cell(self, row: int, col: int, contents: str, state: str) -> None:
        '''set contents and state of given cell'''
        if row < 0:
            return
        self._set_cell_contents(row, col, contents)
        self._set_cell_state(row, col, state)

    def _set_cell_contents(self, row: int, col: int, contents: str) -> None:
        if row < 0:
            return
        self._board[row][col] = contents

    def _set_cell_state(self, row: int, col: int, state: str) -> None:
        if row < 0:
            return
        self._boardStates[row][col] = state

    def _gravity(self) -> None:
        '''make all cells down if it is not landed'''
        for col in range(self._columns):
            for row in range(self._rows- 1, -1, -1):
                state = self.get_cell_state(row, col)
                if state == FALLER_MOVING_CELL or state == FALLER_STOPPED_CELL:
                    continue
                if state == OCCUPIED_CELL:
                    i = 1
                    while not self._is_land(row + i, col):
                        self._move_cell(row + i - 1, col, DOWN)
                        i += 1

    def _matching(self) -> None:
        for row in range(self._rows):
            for col in range(self._columns):
                if self.get_cell_state(row, col) == MATCHED_CELL:
                    self._set_cell(row, col, EMPTY, EMPTY_CELL)
        self._gravity()

        self._match_horizontal()
        self._match_vertical()
        
        

    def _match_horizontal(self) -> None:
        for matching_row in range(self._rows- 1, -1, -1):
            _match = 0
            status = None
            for col in range(0, self._columns):
                contents = self.get_cell_contents(matching_row, col)
                state = self.get_cell_state(matching_row, col)
                cellMatches = (contents == status and matchable_cell(state))
                if cellMatches:
                    _match += 1
                if col == self._columns-1:
                    if _match >= 3:
                        if cellMatches:
                            self.match_cells(matching_row, col, LEFT, _match)
                        else:
                            self.match_cells(matching_row, col-1, LEFT, _match)
                elif not cellMatches:
                    if _match >= 3:
                        self.match_cells(matching_row, col-1, LEFT, _match)

                    if matchable_cell(state):
                        status = contents
                        _match = 1
                    else:
                        status = None
                        _match = 1
    
                        
    def _match_vertical(self) -> None:
        for matching_col in range(0, self._columns):
            _match = 0
            status = None
            for row in range(self._rows - 1, -1, -1):
                contents = self.get_cell_contents(row, matching_col)
                state = self.get_cell_state(row, matching_col)
                cellMatches = (contents == status and matchable_cell(state))
                if cellMatches:
                    _match += 1

                if row == 0:
                    if _match >= 3:
                        if cellMatches:
                            self.match_cells(row, matching_col, DOWN, _match)
                        else:
                            self.match_cells(row + 1, matching_col, DOWN, _match)
                elif not cellMatches:
                    if _match >= 3:
                        self.match_cells(row + 1, matching_col, DOWN, _match)

                    if matchable_cell(state):
                        status = contents
                        _match = 1
                    else:
                        status = None
                        _match = 1

    def match_cells(self, row: int, col: int, direction: int, amount: int) -> None:
        '''change the matchable cell state'''
        if direction == LEFT:
            for target_col in range(col, col - amount, -1):
                self._set_cell_state(row, target_col, MATCHED_CELL)
        elif direction == DOWN:
            for target_row in range(row, row + amount):
                self._set_cell_state(target_row, col, MATCHED_CELL)


    def _update(self) -> None:
        state = None
        target_row = self._faller._row+ 1
        if self._is_land(target_row, self._faller._col):
            state = FALLER_STOPPED_CELL
            self._faller.state = _FALLER_STOPPED
        else:
            state = FALLER_MOVING_CELL
            self._faller.state = _FALLER_MOVING

        for i in range(3):
            row = self._faller._row - i
            if row < 0:
                return
            self._set_cell(row, self._faller._col, self._faller.contents[i], state)

    def _is_land(self, row: int, col: int) -> bool:
        if row >= self._rows:
            return True

        if self.get_cell_state(row, col) == OCCUPIED_CELL:
            return True

        return False

    def _move_faller_down(self) -> None:
        if self._is_land(self._faller._row + 1, self._faller._col):
            return

        self._move_cell(self._faller._row, self._faller._col, DOWN)
        if self._faller._row - 1 >= 0:
            self._move_cell(self._faller._row - 1, self._faller._col, DOWN)
            if self._faller._row - 2 >= 0:
                self._move_cell(self._faller._row - 2, self._faller._col, DOWN)
            else:
                self._set_cell(self._faller._row - 1, self._faller._col, self._faller.contents[2],
                               FALLER_MOVING_CELL)
        else:
            self._set_cell(self._faller._row, self._faller._col, self._faller.contents[1], FALLER_MOVING_CELL)

        self._faller.set_row(self._faller._row + 1)

    def _move_cell(self, row: int, col: int, direction: int) -> None:
        '''move cell to the given direction'''
        old_content = self._board[row][col]
        old_state = self._boardStates[row][col]

        self._board[row][col] = EMPTY
        self._boardStates[row][col] = EMPTY_CELL

        if direction == DOWN:
            new_row = row + 1
            self._board[new_row][col] = old_content
            self._boardStates[new_row][col] =old_state
        else:
            new_col = col + direction
            self._board[row][new_col] = old_content
            self._boardStates[row][new_col] =old_state


_FALLER_STOPPED = 0
_FALLER_MOVING = 1

def matchable_cell(state: str) -> bool:
    return state == OCCUPIED_CELL or state == MATCHED_CELL

class _Faller:
    def __init__(self):
        '''create a new faller'''
        self.active = False
        self._row = 0
        self._col = 0
        self.contents = [EMPTY, EMPTY, EMPTY]
        self.state = _FALLER_MOVING

    

    def set_row(self, row: int) -> None:
        '''set the row the faller will be put in'''
        self._row = row

    def set_col(self, col: int) -> None:
        '''set the column the faller will be put in'''
        self._col = col
