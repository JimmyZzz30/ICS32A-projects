import connectfour as lib
import protocol as network
import function as tool

def start_game()->None:
    '''
    The main function of the online version of connect four
    
    '''
    print('Welcome to ConnectFour Game(online)')
    host,port=get_host_and_port()
    connection=network.connect(host,port)
    username=get_username()
    col=int(input("Please input the number of columns:"))
    row=int(input("Please input the number of rows:"))
    a=col
    if not network.hello(connection,username):
        print("Can't connect to the server")
        return
    network.set_game(connection,col,row)
    print("Successfully connected to the server")
    print('')
    game=lib.new_game(col,row)
    while lib.winner(game)==0:
        if game.turn==1:
            tool.print_gamestate(game)
            print('')
            print("It's red player's turn now,make a move")
            while True:
                
                col,move=tool.get_move(a)
            
                network.send_move(connection,move,col)

                response=network._read_line(connection)

                game=tool.make_move(game,col,move)

                break
        else:
            tool.print_gamestate(game)
            print('')
            move,col=network.receive_move(connection)
            game=tool.make_move(game,col,move)
            print("The yellow player has made the move")
    winner=lib.winner(game)
    print()
    tool.print_gamestate(game)
    print('')
    if winner==1:
        print("You won! Congratulations!")
    else:
        print("The AI player won the game")
    network.close(connection)
    return

def get_host_and_port()->(str,int):
    '''
    get the host and port for connection to server

    '''
    host=input("Please input the host you want to connect:")
    a=input("Please input the port to connect:")
    port=int(a)
    return host,port

def get_username()->str:
    '''
    get the username for connecting with server
    '''
    print("Please input your username without space")
    username=input().strip()
    if not ''in username:
        return usename

if __name__ == '__main__':
    start_game()
