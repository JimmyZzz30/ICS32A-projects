from collections import namedtuple
import connectfour as lib
GameState = namedtuple('GameState', ['board', 'turn'])

def print_gamestate(state:lib.GameState)->None:
    for col in range(1,lib.columns(state)+1):
        print(col,end='')
        if col==lib.columns(state):
            print()
        elif col<9:
            print('  ',end='')
        else:
            print(' ',end='')
    for i in range(lib.rows(state)):
        for j in range(lib.columns(state)):
            if state.board[j][i]==lib.RED:
                print('R ',end='')
            elif state.board[j][i]==lib.YELLOW:
                print('Y ',end='')
            else:
                print('. ',end='')
            if j==lib.columns(state)-1:
                print('')
            else:
                print(' ',end='')
                 
    

def print_turn(state:lib.GameState)->None:
    print("It's "+get_player_string(state.turn)+" player's turn" )
def get_player_string(player:int)->str:
    if player==lib.YELLOW:
        return "Yellow"
    elif player==lib.RED:
        return "Red"
    else:
        return "None"
def get_move(col:int)->(int,str):
    while True:
        print("Please select the move(drop or pop) and which column to make the move.eg.'drop 7' ")
        choice=input().strip()
        move=choice[:-2]
        strcol=choice[-1].strip()
        if not strcol.isdigit():
            print("column must be an integer")
            continue
            
        numcol=int(strcol)
        if numcol<1 or numcol>int(col):
            print("column number must be in range")
            continue
        move=move.lower()
        if move=='drop' or move=='pop':
            return numcol,move
def make_move(state:lib.GameState,col:int,move:str):
    move=move.lower()
    if move=='pop':
        return lib.pop(state,int(col)-1)
    else:
        return lib.drop(state,int(col)-1)
    
                

