import socket
from collections import namedtuple

PollingConnection = namedtuple(
    'PollingConnection',
    ['socket', 'input', 'output'])
_SHOW_DEBUG_TRACE=False


class PollingProtocolError(Exception):
    pass
def connect(host: str, port: int) -> PollingConnection:
    '''
    connect to the server with given host and port
    '''
    polling_socket = socket.socket()
    
    polling_socket.connect((host, port))

    polling_input = polling_socket.makefile('r')
    polling_output = polling_socket.makefile('w')

    return PollingConnection(
        socket = polling_socket,
        input = polling_input,
        output = polling_output)

        
def hello(connection:PollingConnection,username:str)->bool:
    '''send hello and username to the server,expect the server to send back
    welcome
    '''
    _write_line(connection,f'I32CFSP_HELLO {username}')
    response=_read_line(connection)
    if response==f'WELCOME {username}':
        return True
    else:
        raise PollingProtocolError()
def set_game(connection:PollingConnection,col:int,row:int)->bool:
    '''
    send game board size to the server
    '''
    line="AI_GAME "+str(col)+' '+str(row)
    
    _write_line(connection,line)


    
def close(connection:PollingConnection)->None:
    '''
    close connection with the server

    '''

    connection.output.close()
    connection.input.close()
    connection.socket.close()



    
def _read_line(connection:PollingConnection)->str:
    '''read a line of text sent from the server and returns it without
    a newline on the end of it
    '''
    line=connection.input.readline()[:-1]
    return line

def _expect_line(connection:PollingConnection,expected:str)->None:
    '''
    read a line of text sent from the server, expecting it to contain
    a particular text.

    '''
    line=_read_line(connection)
    if line!=expected:
        raise PollingProtocolError()


def _write_line(connection:PollingConnection,line=str)->None:
    '''
    write line to the server
    '''
    connection.output.write(line+'\r\n')
    connection.output.flush()

def send_move(connection:PollingConnection,move:str,col:int)->str:
    if move=='drop':
        line="DROP "+str(col)
        _write_line(connection,line)
    elif move=='pop':
        line="POP "+str(col)
        
        
def receive_move(connection:PollingConnection)->(str,int):
    '''
    receieve move from the server and send back a tuple contain move and
    column number
    '''
    line=connection.input.readline()[:-1]
    
    if line=="READY":
        line=connection.input.readline()[:-1]
        if line=="OKAY":
            line=connection.input.readline()[:-1]
            
            move=line[:-2]
            col=int(line[-1])
            return move,col
    if line=="OKAY":
        line=connection.input.readline()[:-1]
        
        move=line[:-2]
        col=int(line[-1])
        return move,col
    
        
        
        

   
    
