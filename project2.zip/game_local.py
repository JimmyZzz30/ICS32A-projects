import connectfour as lib
import function as tool
def start_game()->None:
    print('Welcome to ConnectFour Game')
    print("Please input the size of the game board")
    col=int(input("Please input the number of columns:"))
    row=int(input("Please input the number of rows:"))
    game=lib.new_game(col,row)
    a=col
    while lib.winner(game)==0:
        tool.print_gamestate(game)
        tool.print_turn(game)
        while True:
            
            col,move=tool.get_move(a)
            try:
                game=tool.make_move(game,col,move)
                break
            except lib.InvalidMoveError:
                if move=='drop':
                    print("Can't drop there,make another try")
                else:
                    print("Can't pop there,make another try")
                    
    winner=lib.winner(game)
    tool.print_gamestate(game)
    print(tool.get_player_string(winner)+' player won the game! Congratulations!')




















if __name__ == '__main__':
    start_game()
