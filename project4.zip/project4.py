import columns_game as game


def run() -> None:
    rows = int(input())
    cols = int(input())
    state = game.GameState(rows, cols)

    line = read_line()
    if line == 'CONTENTS':
        contents = []
        for i in range(rows):
            row = []
            content = read_line()
            for index in range(cols):
                row.append(content[index])
            contents.append(row)
        state.set_board_contents(contents)

    while True:
        display(state)
        command = read_line()
        if command == 'Q':
            return
        if command == '':
            if state.tick():
                display(state)
                break
        else:
            process_command(command, state)
    print('GAME OVER')


def process_command(command: str, state: game.GameState) -> None:
    if command == 'R':
        state.rotate_faller()
    elif command == '<':
        state.move_faller_side(-1)
    elif command == '>':
        state.move_faller_side(1)
    elif command[0] == 'F':
        try:
            contents = command.split()
            column= int(contents[1])
            faller = [contents[-1], contents[-2], contents[-3]]
            if contents[-1] or contents[-2] or contents[-3] not in game.CONTENTS:
                return
            state.create_faller(column, faller)
        except:
            return


def display(state: game.GameState) -> None:
    for row in range(state._rows):
        line = "|"
        for col in range(state._columns):
            cellValue = state.get_cell_contents(row, col)
            cell_state = state.get_cell_state(row, col)
            if cell_state == game.EMPTY_CELL:
                line += '   '
            elif cell_state == game.OCCUPIED_CELL:
                line += (' ' + cellValue + ' ')
            elif cell_state == game.FALLER_MOVING_CELL:
                line += ('[' + cellValue + ']')
            elif cell_state == game.FALLER_STOPPED_CELL:
                line += ('|' + cellValue + '|')
            elif cell_state == game.MATCHED_CELL:
                line += ('*' + cellValue + '*')
        line+= '|'
        print(line)
    finalLine = ' '
    for col in range(state._columns):
        finalLine += '---'
    finalLine += ' '
    print(finalLine)

def read_line() -> str:
    return input()





# This makes it so this module is executable
if __name__ == '__main__':
    run()
